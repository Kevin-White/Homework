cat $1 > final_file.txt
cat $2 >> final_file.txt
cat $3 >> final_file.txt