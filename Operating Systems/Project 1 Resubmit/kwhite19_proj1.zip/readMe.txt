This program is a super basic UI and User Iteractiable Command Line Inter Face for Unix/Linux.
This is for Project1 in 3346 Operating Systems

I used code from:
https://stackoverflow.com/questions/875249/how-to-get-current-directory
To help with printing working directory for the program.

I also got the class structure from the helpfull code examples you provided
