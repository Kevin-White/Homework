This project is for implementation of bankers algorithm

type "make" in order to make the nessisary files needed

Then type "./kwhite19_proj4.exe (inputFile)" in order to run the program

the output will then take and proccess the input file.


type "make clean" to clean up any extra files
