#!/bin/bash
echo "Scripting is fun!"

