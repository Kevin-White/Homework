import math

radius = int(input("What is the radius: "))
volume = (4/3) * math.pi * (radius**3)
print("The volume of the sphere is: {:0.3f}".format(volume))
