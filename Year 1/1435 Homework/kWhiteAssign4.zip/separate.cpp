//********************************************************************
//Name: Kevin White
//Class: COSC 1435 Fall 20
//Instructor: Marwa Hassan
//Assignment x Problem x
//Date:9/28/2020
//Program description: Prints out each digit in a 5-digit int given
//*********************************************************************

#include <iostream>
using namespace std;

int main()
{
// Getting the 5 didget number from the user.
    int x;
    cout << "Please enter a five-digit integer:";
    cin >> x;

// Getting each digen from the nuumber by deviding by greatest placeholder. 
    cout << x/10000 << "   ";
    x %= 10000;
    cout << x/1000 << "   ";
    x %= 1000;
    cout << x/100 << "   ";
    x %= 100;
    cout << x/10 << "   ";
    x %= 10;
    cout << x << "   ";
    return 0;
    
    
}
